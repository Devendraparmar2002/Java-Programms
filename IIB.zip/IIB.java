class A1
{
	{
		System.out.println("IIB of Base class");
	}
	public void disp()
	{
		System.out.println("This is disp");
	}
}
public class IIB extends A1
{
	public static void main(String [] args)
	{
		A1 b = new A1();
		b.disp();
	}
}


/*output :

IIB of Base class
This is disp

*/