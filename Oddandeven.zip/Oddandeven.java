import java.util.*;

public class Oddandeven 
{

    public static void main(String[] args) 
	{

        Scanner reader = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int num = reader.nextInt();

        if(num % 2 == 0)
            System.out.println(num + " is even");
        else
            System.out.println(num + " is odd");
    }
}




/*output:
Enter a number : 15
15 id odd
Enter a number : 20
20 is even */