public class Book
{
	int bookprc;
	String booknm;
	Book()
	{
		System.out.println("No Data Available");
	}
	Book (int a)
	{
		this.bookprc = a;
		System.out.println("This book cost"+bookprc);
	}
	Book (int a, String s)
	{
		this.bookprc = a;
		this.booknm = s;
		System.out.println(booknm+"Costs "+bookprc);
	}
	public static void main(String [] args)
	{
		Book b1 = new Book(10);
		Book b2 = new Book(10,"Samvad ");
	}
}