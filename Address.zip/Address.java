//To read the user address and display it
import java.util.Scanner;

public class Address 
{
	
	public static void main(String args[])
	
	{
		String address;
		System.out.println("Enter address:\n");
		Scanner obj1=new Scanner(System.in);
		address=obj1.nextLine();
		System.out.println("Your Address is : "+address);
	}
	
}			



/*output:
Enter address:

parsana nagar street no - 3 "Aasutosh" jamanagr road Rajkot.

Your Address is : parsana nagar street no - 3 "Aasutosh" jamanagr road Rajkot.
*/