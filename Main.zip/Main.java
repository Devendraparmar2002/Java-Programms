import java.util.Scanner;

public class Main
{
	public static void main(String [] args)
	{
		Scanner input = new Scanner (System.in);
		System.out.println("Enter the first Number: ");
		int num1 = input.nextInt();
		System.out.println("Enter the second Number: ");
		int num2 = input.nextInt();
		int sum = num1 * num2;
		int sum2 = num1 + num2;
		System.out.println();
		System.out.println("multiplication: "+sum);
		System.out.println();
		System.out.println("addition: "+sum2);
		
	}
}



/*output:
Enter the first number : 
15
Enter the second number :
20

multiplication: 300

addition:35
*/