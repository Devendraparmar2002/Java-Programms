class Percentage
{
	public static void main(String args[])
		{
			int a,b,c,d,total;
			float mark;
			a=91;
			System.out.println("enter My subject 1 mark = "+a);

			b=80;
			System.out.println("enter My subject 2 mark = "+b);

			c=87;
			System.out.println("enter My subject 3 mark = "+c);

			d=98;
			System.out.println("enter My subject 4 mark = "+d);

			total = a+b+c+d;

			System.out.println("total is :"+total);
			mark = total / 4;
			System.out.println("Percentage is :="+mark);
			
			System.out.println("/n my frd maik is =>");
			
			int a1,b1,c1,d1,total1;
			float Percentage;
			a1=98;
			System.out.println("enter friend subject 1 mark = "+a1);

			b1=80;
			System.out.println("enter friend subject 2 mark = "+b1);

			c1=86;
			System.out.println("enter friend subject 3 mark = "+c1);

			d1=65;
			System.out.println("enter friend subject 4 mark = "+d1);

			total1 = a1+b1+c1+d1;

			System.out.println("total is :"+total1);
			Percentage = total1 / 4;
			System.out.println("Percentage is :="+Percentage);
		}
}



/*output:
enter subjact 1 mark = 91
enter subjact 2 mark = 80
enter subjact 3 mark = 87
enter subjact 4 mark = 98
total is : 365
Percentage is : 89.0
/n my friend mark is =>
enter friend subjact 1 mark = 98
enter friend subjact 2 mark = 80
enter friend subjact 3 mark = 86
enter friend subjact 4 mark = 65
total is : 329
Percentage is : 82.0
*/