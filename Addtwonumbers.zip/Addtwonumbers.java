import java.util.Scanner;

public class Addtwonumbers
{
	public static void main(String [] args)
	{
		Scanner sc = new Scanner(System.in);
		int FirstNumber = sc.nextInt();
		int SecondNumber = sc.nextInt();
		int result = FirstNumber + SecondNumber;
		System.out.print(result);
	}
}




/*output:
15
10
35
*/